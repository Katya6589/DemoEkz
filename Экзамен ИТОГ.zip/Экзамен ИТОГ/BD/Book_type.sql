BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "Book_type" (
	"ID"	INTEGER,
	"Type"	TEXT,
	"Kooeficent"	REAL,
	PRIMARY KEY("ID")
);
INSERT INTO "Book_type" ("ID","Type","Kooeficent") VALUES (1,'Художественная',1.5),
 (2,'Научная',2.25),
 (3,'Детская',1.0),
 (4,'Учебник',2.0),
 (5,'Справочник',1.75);
COMMIT;
