from PyQt5.QtWidgets import QListWidget, QListWidgetItem, QLabel, QMessageBox, QPushButton
from PyQt5.QtCore import QSize, Qt
from PyQt5 import QtCore
from db import get_partners

from AddPartner import AddPartner
from EditPartner import EditPartner

class PartnersView:
    def __init__(self, ui, cursor):
        super(PartnersView, self).__init__()
        self.ui = ui
        self.cursor = cursor
        
        self.btnSave = self.ui.findChild(QPushButton, "btnSave")
        self.btnHistory = self.ui.findChild(QPushButton, "btnHistory")
        self.Add_button = self.ui.findChild(QPushButton, "Add_button")
        # ищем нужные виджеты
        self.list_view = self.ui.findChild(QListWidget, "list_view")
        self.btn_add = self.ui.findChild(QPushButton, "btnAddPartner")

        self.btn_add.clicked.connect(self.add_partner)

        self.list_view.itemClicked.connect(self.show_partner_details)

        self.ui.stackedWidget.currentChanged.connect(self.on_page_changed)
      
    def on_page_changed(self, index): #для обновлеия списка после добавления
        current_widget = self.ui.stackedWidget.widget(index)
        if current_widget == self.ui.pagePartners:
            self.load_partners()

    def load_partners(self):
        try:
            partners = get_partners(self.cursor)
            if not partners:
                QMessageBox.warning(None, "Предупреждение", "Партнёры не найдены.", QMessageBox.Ok)
                return

            self.list_view.clear()

            for partner in partners:
                inn, html = self.format_partner_info(partner)
                item = QListWidgetItem()
                label = QLabel()
                label.setText(html)
                label.setWordWrap(True)
                label.setTextFormat(Qt.RichText)
                label.adjustSize()
                item.setSizeHint(QSize(label.width(), label.height() + 20))
                item.setData(QtCore.Qt.UserRole, inn)
                self.list_view.addItem(item)
                self.list_view.setItemWidget(item, label)
                label.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, True)

        except Exception as e:
            QMessageBox.critical(None, "Ошибка", f"Ошибка загрузки: {e}", QMessageBox.Ok)

    def format_partner_info(self, partner):
        inn = partner[0]
        tip = partner[1]
        name = partner[2]
        total_quantity = partner[3] if partner[3] else 0
        telefon = partner[4] or "Телефон не указан"
        rejting = partner[5]
        director = f"{partner[6]} {partner[7]} {partner[8]}".strip() or "Директор не указан"
        discount = self.calculate_discount(total_quantity)

        html = f"""
        <div style='font-size: 14pt;'>
            <table width='100%'>
                <tr>
                    <td style='width: 70%;'><b>{tip}</b> | {name}</td>
                    <td style='width: 30%; text-align: right;'>
                        <span style='color:#333;'>{discount}%</span>
                    </td>
                </tr>
            </table>
        </div>
        <div style='font-size: 10pt; color:#666; margin-top: 8px; line-height: 1.4;'>
            <div>{director}</div>
            <div>{telefon}</div>
            <div>Рейтинг: {rejting}</div>
        </div>
        """
        return inn, html

    def calculate_discount(self, quantity):
        if quantity < 10000:
            return 0
        elif quantity < 50000:
            return 5
        elif quantity < 300000:
            return 10
        else:
            return 15

    def add_partner(self, item):

        #inn = item.data(QtCore.Qt.UserRole)

        self.ui.stackedWidget.setCurrentWidget(self.ui.pageAddPartner)

        self.lybaya = AddPartner(self.ui, self.cursor)
        
        self.btnSave.hide()
        self.btnHistory.hide()
        self.Add_button.show()
        

    def show_partner_details(self, item):
        inn = item.data(QtCore.Qt.UserRole)
        self.ui.stackedWidget.setCurrentWidget(self.ui.pageAddPartner)
        self.lybaya = EditPartner(self.ui, self.cursor, inn)
        

        self.btnSave.show()
        self.btnHistory.show()
        self.Add_button.hide()
        


        