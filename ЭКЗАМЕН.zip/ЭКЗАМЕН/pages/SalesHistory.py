from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (
    QDialog, QTableWidgetItem, QTableWidget, QMessageBox,QLabel, QPushButton, QLineEdit, QComboBox, QSpinBox
)
import sqlite3
from pages.db import get_sales_history
import re
from pages.SavePartner import SavePartner
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox
from pages.db import get_sales_history
#from EditPartner import EditPartner

class SalesHistory(QDialog):
    def __init__(self, ui, cursor, inn):
        super(SalesHistory, self).__init__()
        self.ui = ui
        self.cursor = cursor
        self.partner_inn = inn

        self.load_sales_history()  

        self.back_btn = self.ui.findChild(QPushButton, "back_btn")
        self.back_btn.clicked.connect(self.back)
        

    def load_sales_history(self):
        self.table_widget = self.ui.findChild(QTableWidget, "table_widget")
        self.table_widget.clearContents()
        self.table_widget.setRowCount(0)
        self.table_widget.setColumnCount(3)
        self.table_widget.setHorizontalHeaderLabels(["Продукт", "Количество", "Дата"])
        
        try:
            sales = get_sales_history(self.cursor, self.partner_inn)
            if not sales:
                QMessageBox.information(None, "История реализации", "У партнера нет истории продаж.", QMessageBox.Ok)
                return

            self.table_widget.setRowCount(len(sales)) #table_widget      sales
            for row, (product_name, quantity, date) in enumerate(sales):
                self.table_widget.setItem(row, 0, QTableWidgetItem(str(product_name))) 
                self.table_widget.setItem(row, 1, QTableWidgetItem(str(quantity)))
                self.table_widget.setItem(row, 2, QTableWidgetItem(str(date)))
        except Exception as e:
            print(f"Ошибка при загрузке истории продаж: {e}")
            QMessageBox.critical(None, "Ошибка", f"Не удалось загрузить историю продаж. Подробности: {e}", QMessageBox.Ok)

    def back(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.pageAddPartner) #pageAddPartner
        from pages.EditPartner import EditPartner  # ← импорт внутрь функции
        self.lybaya = EditPartner(self.ui, self.cursor, inn=None)
