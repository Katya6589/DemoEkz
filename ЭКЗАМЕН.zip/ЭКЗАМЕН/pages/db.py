import sqlite3

def connect_db():
    try:
        conn = sqlite3.connect("BD/Master_pol.db")
        cursor = conn.cursor()
        print("Подключение к базе данных успешно.")
        return conn, cursor
    except sqlite3.Error as e:
        print(f"Ошибка подключения к базе данных: {e}")
        return None, None

def get_partners(cursor):
    query = """
    SELECT 
        p.ID_INN, pt.Tip, p.Naimenovanie_partnera, 
        SUM(pp.Kolichestvo_produkcii) AS total_quantity,
        p.Telefon_partnera, p.Rejting,
        p.Familiya, p.Imya, p.Otchestvo
    FROM 
        Partners p
    JOIN 
        Partners_type pt ON p.Tip_partnera_ID = pt.ID_Tip_partnera
    LEFT JOIN 
        Partner_products pp ON p.ID_INN = pp.INN_ID
    GROUP BY 
        p.ID_INN, pt.Tip, p.Naimenovanie_partnera,
        p.Telefon_partnera, p.Rejting,
        p.Familiya, p.Imya, p.Otchestvo;
    """
    cursor.execute(query)
    cursor.connection.commit()
    return cursor.fetchall()

def add_partner(cursor, data):
    query = """
    INSERT INTO Partners (
        ID_INN, Naimenovanie_partnera, Tip_partnera_ID, Rejting, Indeks, 
        Oblast, Gorod, Ulica, Dom, Familiya, Imya, Otchestvo, 
        Telefon_partnera, Elektronnaya_pochta_partnera
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """
    cursor.execute(query, data)
    cursor.connection.commit()
    return cursor

def update_partner(cursor, data):
    query = """
    UPDATE Partners
    SET 
        Naimenovanie_partnera = ?, 
        Tip_partnera_ID = ?, 
        Rejting = ?, 
        Telefon_partnera = ?, 
        Elektronnaya_pochta_partnera = ?,
        Indeks = ?, 
        Oblast = ?, 
        Gorod = ?, 
        Ulica = ?, 
        Dom = ?,
        Familiya = ?, 
        Imya = ?, 
        Otchestvo = ?
    WHERE ID_INN = ?;
    """
    cursor.execute(query, data)
    return cursor

def get_sales_history(cursor, inn):
    query = """
    SELECT 
        p.Naimenovanie_produkcii, pp.Kolichestvo_produkcii, pp.Data_prodazhi
    FROM 
        Partner_products pp
    JOIN 
        Products p ON pp.Artikul_ID = p.ID_Artikul
    WHERE 
        pp.INN_ID = ?;
    """
    print("Ищем историю по ИНН:", inn)

    cursor.execute(query, (inn,))
    return cursor.fetchall()

def get_partner_types(cursor):
    query = "SELECT ID_Tip_partnera, Tip FROM Partners_type;"
    cursor.execute(query)
    return cursor.fetchall()

def get_partner_type(cursor):
    query = "SELECT DISTINCT Tip FROM Partners_type;"
    cursor.execute(query)
    return cursor.fetchall()

def get_partner_data(cursor, inn):
    query = """
    SELECT 
        ID_INN, Naimenovanie_partnera, Tip_partnera_ID, Rejting, Telefon_partnera, 
        Elektronnaya_pochta_partnera, Indeks, Oblast, Gorod, Ulica, Dom, 
        Familiya, Imya, Otchestvo
    FROM 
        Partners
    WHERE ID_INN = ?;
    """
    cursor.execute(query, (inn,))
    cursor.connection.commit()
    return cursor.fetchone()