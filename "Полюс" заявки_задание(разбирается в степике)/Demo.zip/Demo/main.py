#  widget - это имя, присваиваемое компоненту пользовательского интерфейса,
#  с которым пользователь может взаимодействовать 
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (
    QApplication, # это то, что поддерживает работоспособность приложения Qt, выполняя его основной цикл событий
    QDialog # это базовый класс диалогового окна
)
from PyQt5.uic import loadUi # загрузка интерфейса, созданного в Qt Creator
import sys # взаимодействие с интерпретатором
from PyQt5.QtGui import QPixmap, QIcon # для работы с изображениями и загрузки иконок
import sqlite3

# Окно приветствия
class WelcomeScreen(QDialog):
    def __init__(self):
        super(WelcomeScreen, self).__init__()
        loadUi("dialog_Stepik.ui",self) # загружаем интерфейс
        self.PasswordField.setEchoMode(QtWidgets.QLineEdit.Password)
        self.pushButton.clicked.connect(self.Bxod)

    def Bxod(self):
        print(2)
        user = self.SigningField.text() # получени написанных данных с формы (Text())
        pvd = self.PasswordField.text()
        userinfo = [user, pvd]
        
        if user == "" or pvd == "":
            self.ErrorFiled.setText("Заполните все поля")
        else:
            print(user, pvd)
            conn = sqlite3.connect("uchet.db") #ПОДКЛЮЧЕНИЕ К БАЗЕ
            cur = conn.cursor() #получили элемент базы 
            cur.execute(f"select * from users where login = ? and password = ?", (user, pvd))
            #cur.execute('select * from users where login = "login1" and password = "pass1"')

            typeuser = cur.fetchone()
            print(typeuser)
            conn.commit()
            conn.close()

        


        
# запуcк приложения
app = QApplication(sys.argv)

# позволяте менять страницы в окне
welcome = WelcomeScreen()
widget = QtWidgets.QStackedWidget()
widget.addWidget(welcome)

# загружаем иконку
icon = QIcon()
icon.addPixmap(QPixmap("книга.png"), QIcon.Normal, QIcon.Off)
widget.setWindowIcon(icon) 
widget.show()

                # запускаем приложение
try:
    sys.exit(app.exec_())
except:
    print("You close application")