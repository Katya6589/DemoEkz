from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QListWidget, QLabel, QMessageBox, QListWidgetItem
from PyQt5.QtCore import Qt, QSize
from db import get_partners

class PartnersPage(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        layout = QVBoxLayout()
        self.list_view = QListWidget()
        self.list_view.setStyleSheet("""
            QListWidget {
                background-color: white;
                outline: 0;
            }
            QListWidget::item {
                border: 1px solid #ddd;
                padding: 14px;
                margin: 5px;
                min-height: 140px;
            }
            QListWidget::item:selected {
                background-color: #f0f0f0;
            }
        """)
        self.list_view.itemClicked.connect(self.on_item_clicked)
        layout.addWidget(self.list_view)
        add_button = QPushButton("Добавить")
        add_button.setStyleSheet("background-color: #67BA80;")
        add_button.clicked.connect(self.add_partner)
        layout.addWidget(add_button)
        self.setLayout(layout)
        self.load_partners()

    def on_item_clicked(self, item):
        selected_inn = item.data(Qt.UserRole)
        if selected_inn:
            self.parent.page_edit.load_partner_data(selected_inn)
            self.parent.stacked_widget.setCurrentWidget(self.parent.page_edit)

    def add_partner(self):
        self.parent.stacked_widget.setCurrentWidget(self.parent.page_add)

    def load_partners(self):
        try:
            partners = get_partners(self.parent.cursor)
            if not partners:
                QMessageBox.warning(None, "Предупреждение", "В базе данных отсутствуют партнеры.", QMessageBox.Ok)
                return

            for partner in partners:
                inn, html = self.format_partner_info(partner)
                item = QListWidgetItem()
                label = QLabel()
                label.setText(html)
                label.setContentsMargins(0, 0, 0, 0)
                label.setStyleSheet("background-color: transparent;")
                label.setWordWrap(True)
                label.setTextFormat(Qt.RichText)
                label.adjustSize()
                item.setSizeHint(QSize(label.width(), label.height() + 20))
                item.setData(Qt.UserRole, inn)
                self.list_view.addItem(item)
                self.list_view.setItemWidget(item, label)
                label.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        except Exception as e:
            QMessageBox.critical(None, "Ошибка", f"Не удалось загрузить список партнеров: {e}", QMessageBox.Ok)

    def format_partner_info(self, partner):
        inn = partner[0]
        tip = partner[1]
        name = partner[2]
        total_quantity = partner[3] if partner[3] else 0
        telefon = partner[4].strip() if partner[4] else "Телефон не указан"
        rejting = partner[5]
        discount = self.calculate_discount(total_quantity)
        director = f"{partner[6]} {partner[7]} {partner[8]}".strip() or "Директор не указан"

        html = f"""
        <div style='font-size: 14pt;'>
            <table width='100%'>
                <tr>
                    <td style='width: 70%;'><b>{tip}</b> | {name}</td>
                    <td style='width: 30%; text-align: right;'>
                        <span style='color:#333;'>{discount}%</span>
                    </td>
                </tr>
            </table>
        </div>
        <div style='font-size: 10pt; color:#666; margin-top: 8px; line-height: 1.4;'>
            <div>{director}</div>
            <div>{telefon}</div>
            <div>Рейтинг: {rejting}</div>
            <div></div>
        </div>
        """
        return inn, html

    def calculate_discount(self, quantity):
        if quantity < 10000:
            return 0
        elif 10000 <= quantity < 50000:
            return 5
        elif 50000 <= quantity < 300000:
            return 10
        else:
            return 15