import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QStackedWidget
)
from PyQt5.QtGui import QIcon, QFont, QPixmap
from PyQt5.QtCore import Qt, QSize
from db import connect_to_database, create_tables, insert_test_data
from PartnersView import PartnersPage
from EditPartner import EditPartnerPage
from AddPartner import AddPartnerPage
from SalesHistory import SalesHistoryPage

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Мастер пол")
        self.setWindowIcon(QIcon("logo.ico"))
        self.setGeometry(100, 100, 800, 600)

        font = QFont("Segoe UI", 12)
        self.setFont(font)
        self.setStyleSheet("background-color: #F4E8D3;")

        self.db_connection, self.cursor = connect_to_database()
        if not self.db_connection or not self.cursor:
            print("База данных не инициализирована. Завершение работы программы.")
            sys.exit(1)

        create_tables(self.cursor)
        insert_test_data(self.cursor, self.db_connection)

        main_layout = QVBoxLayout()

        header_layout = QHBoxLayout()
        logo_label = QLabel()
        pixmap = QPixmap("logo.png").scaled(QSize(100, 100), Qt.KeepAspectRatio)
        logo_label.setPixmap(pixmap)
        title_label = QLabel("Мастер пол")
        title_label.setFont(QFont("Segoe UI", 24, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        header_layout.addWidget(logo_label, alignment=Qt.AlignLeft)
        header_layout.addWidget(title_label, stretch=1, alignment=Qt.AlignCenter)

        self.stacked_widget = QStackedWidget()
        self.page_partners = PartnersPage(self)
        self.page_edit = EditPartnerPage(self)
        self.page_add = AddPartnerPage(self)
        self.stacked_widget.addWidget(self.page_partners)
        self.stacked_widget.addWidget(self.page_edit)
        self.stacked_widget.addWidget(self.page_add)

        button_layout = QHBoxLayout()
        back_button = QPushButton("Назад")
        back_button.setStyleSheet("background-color: #67BA80;")
        back_button.clicked.connect(self.go_back)
        button_layout.addWidget(back_button, alignment=Qt.AlignLeft)

        main_layout.addLayout(header_layout)
        main_layout.addWidget(self.stacked_widget)
        main_layout.addLayout(button_layout)

        container = QWidget()
        container.setLayout(main_layout)
        self.setCentralWidget(container)

    def go_back(self):
        self.stacked_widget.setCurrentWidget(self.page_partners)

    def closeEvent(self, event):
        if self.db_connection:
            self.db_connection.close()
            print("Соединение с базой данных закрыто.")
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())