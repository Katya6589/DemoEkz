from PyQt5.QtWidgets import QPushButton, QHBoxLayout, QMessageBox
from SavePartner import PartnerForm

class AddPartnerPage(PartnerForm):
    def __init__(self, parent):
        super().__init__(parent)
        button_layout = QHBoxLayout()
        add_button = QPushButton("Добавить")
        add_button.setStyleSheet("background-color: #67BA80;")
        add_button.clicked.connect(self.add_partner)
        button_layout.addWidget(add_button)
        self.layout().addLayout(button_layout)

    def add_partner(self):
        for label in self.error_labels.values():
            label.hide()
        if not self.validate_input():
            QMessageBox.warning(self, "Ошибка", "Проверьте правильность заполнения полей", QMessageBox.Ok)
            return
        self.save_partner()
        QMessageBox.information(None, "Успешно", "Партнер успешно добавлен.", QMessageBox.Ok)
        self.parent.page_partners.list_view.clear()
        self.parent.page_partners.load_partners()
        self.parent.stacked_widget.setCurrentWidget(self.parent.page_partners)