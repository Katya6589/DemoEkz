from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox
from db import get_sales_history

class SalesHistoryPage(QWidget):
    def __init__(self, parent, partner_inn):
        super().__init__()
        self.parent = parent
        self.partner_inn = partner_inn

        layout = QVBoxLayout()

        self.table_widget = QTableWidget()
        self.table_widget.setColumnCount(3)
        self.table_widget.setHorizontalHeaderLabels(["Продукт", "Количество", "Дата"])
        self.table_widget.setStyleSheet("background-color: white;")

        horizontal_header = self.table_widget.horizontalHeader()
        horizontal_header.setSectionResizeMode(QHeaderView.Stretch)
        horizontal_header.setStretchLastSection(True)

        layout.addWidget(self.table_widget)

        button_layout = QHBoxLayout()
        back_button = QPushButton("Назад")
        back_button.setStyleSheet("background-color: #67BA80;")
        back_button.clicked.connect(self.go_back)
        button_layout.addWidget(back_button)

        layout.addLayout(button_layout)
        self.setLayout(layout)

        self.load_sales_history()

    def load_sales_history(self):
        try:
            sales = get_sales_history(self.parent.cursor, self.partner_inn)
            if not sales:
                QMessageBox.information(None, "История реализации", "У партнера нет истории продаж.", QMessageBox.Ok)
                return

            self.table_widget.setRowCount(len(sales))
            for row, sale in enumerate(sales):
                product_name, quantity, date = sale
                self.table_widget.setItem(row, 0, QTableWidgetItem(product_name))
                self.table_widget.setItem(row, 1, QTableWidgetItem(str(quantity)))
                self.table_widget.setItem(row, 2, QTableWidgetItem(str(date)))
        except Exception as e:
            print(f"Ошибка при загрузке истории продаж: {e}")
            QMessageBox.critical(None, "Ошибка", f"Не удалось загрузить историю продаж. Подробности: {e}", QMessageBox.Ok)

    def go_back(self):
        self.parent.stacked_widget.setCurrentWidget(self.parent.page_partners)