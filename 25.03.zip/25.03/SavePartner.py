import re
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QFormLayout, QLineEdit, QComboBox, QSpinBox, QLabel, QMessageBox
from PyQt5.QtCore import Qt
from db import get_partner_types, add_partner, update_partner

class PartnerForm(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        layout = QVBoxLayout()
        form_layout = QFormLayout()

        self.inn_input = QLineEdit()
        self.name_input = QLineEdit()
        self.type_combo = QComboBox()
        self.rating_spin = QSpinBox()
        self.index_input = QLineEdit()
        self.region_input = QLineEdit()
        self.city_input = QLineEdit()
        self.street_input = QLineEdit()
        self.house_input = QLineEdit()
        self.director_last_name_input = QLineEdit()
        self.director_first_name_input = QLineEdit()
        self.director_middle_name_input = QLineEdit()
        self.phone_input = QLineEdit()
        self.email_input = QLineEdit()

        self.error_labels = {
            'inn': QLabel(""),
            'name': QLabel(""),
            'rating': QLabel(""),
            'index': QLabel(""),
            'phone': QLabel(""),
            'email': QLabel(""),
            'director': QLabel("")
        }

        for label in self.error_labels.values():
            label.setStyleSheet("color: red; font-size: 10pt;")
            label.hide()

        form_layout.addRow("ИНН:", self.inn_input)
        form_layout.addRow("", self.error_labels['inn'])
        form_layout.addRow("Наименование:", self.name_input)
        form_layout.addRow("", self.error_labels['name'])
        form_layout.addRow("Тип партнера:", self.type_combo)
        form_layout.addRow("Рейтинг:", self.rating_spin)
        form_layout.addRow("", self.error_labels['rating'])
        form_layout.addRow("Индекс:", self.index_input)
        form_layout.addRow("", self.error_labels['index'])
        form_layout.addRow("Область:", self.region_input)
        form_layout.addRow("Город:", self.city_input)
        form_layout.addRow("Улица:", self.street_input)
        form_layout.addRow("Дом:", self.house_input)
        form_layout.addRow("Фамилия директора:", self.director_last_name_input)
        form_layout.addRow("Имя директора:", self.director_first_name_input)
        form_layout.addRow("Отчество директора:", self.director_middle_name_input)
        form_layout.addRow("", self.error_labels['director'])
        form_layout.addRow("Телефон:", self.phone_input)
        form_layout.addRow("", self.error_labels['phone'])
        form_layout.addRow("Email:", self.email_input)
        form_layout.addRow("", self.error_labels['email'])

        layout.addLayout(form_layout)
        self.setLayout(layout)

        self.load_types()

    def load_types(self):
        try:
            types = get_partner_types(self.parent.cursor)
            for type_id, type_name in types:
                self.type_combo.addItem(type_name, type_id)
        except Exception as e:
            print(f"Ошибка при загрузке типов партнеров: {e}")

    def validate_input(self):
        valid = True

        inn = self.inn_input.text()
        if not inn.isdigit() or len(inn) != 12:
            self.error_labels['inn'].setText("ИНН должен содержать ровно 12 цифр")
            self.error_labels['inn'].show()
            valid = False
        else:
            self.error_labels['inn'].hide()

        name = self.name_input.text().strip()
        if not name:
            self.error_labels['name'].setText("Наименование не может быть пустым")
            self.error_labels['name'].show()
            valid = False
        else:
            self.error_labels['name'].hide()

        rating = self.rating_spin.value()
        if not (0 <= rating <= 10):
            self.error_labels['rating'].setText("Рейтинг должен быть от 0 до 10")
            self.error_labels['rating'].show()
            valid = False
        else:
            self.error_labels['rating'].hide()

        index = self.index_input.text()
        if not index.isdigit() or len(index) != 6:
            self.error_labels['index'].setText("Индекс должен содержать 6 цифр")
            self.error_labels['index'].show()
            valid = False
        else:
            self.error_labels['index'].hide()

        phone = self.phone_input.text()
        if not re.match(r'^\+7 \d{3} \d{3} \d{2} \d{2}$', phone):
            self.error_labels['phone'].setText("Формат: +7 XXX XXX XX XX")
            self.error_labels['phone'].show()
            valid = False
        else:
            self.error_labels['phone'].hide()

        email = self.email_input.text()
        if not re.match(r'.+@.+\..+', email):
            self.error_labels['email'].setText("Неверный формат email")
            self.error_labels['email'].show()
            valid = False
        else:
            self.error_labels['email'].hide()

        director_fields = [
            self.director_last_name_input.text().strip(),
            self.director_first_name_input.text().strip(),
            self.director_middle_name_input.text().strip()
        ]
        if not all(director_fields):
            self.error_labels['director'].setText("Заполните ФИО директора полностью")
            self.error_labels['director'].show()
            valid = False
        else:
            self.error_labels['director'].hide()

        return valid

    def save_partner(self):
        for label in self.error_labels.values():
            label.hide()
        if not self.validate_input():
            QMessageBox.warning(self, "Ошибка", "Проверьте правильность заполнения полей", QMessageBox.Ok)
            return

        inn = self.inn_input.text()
        name = self.name_input.text()
        type_id = self.type_combo.currentData()
        rating = self.rating_spin.value()
        index = self.index_input.text()
        region = self.region_input.text()
        city = self.city_input.text()
        street = self.street_input.text()
        house = self.house_input.text()
        last_name = self.director_last_name_input.text()
        first_name = self.director_first_name_input.text()
        middle_name = self.director_middle_name_input.text()
        phone = self.phone_input.text()
        email = self.email_input.text()

        try:
            if hasattr(self, 'inn') and self.inn:  # Редактирование
                data = (
                    name, type_id, rating, phone, email,
                    index, region, city, street, house,
                    last_name, first_name, middle_name,
                    inn
                )
                update_partner(self.parent.cursor, self.parent.db_connection, data)
                QMessageBox.information(None, "Успешно", "Данные партнера обновлены.", QMessageBox.Ok)
            else:  # Добавление
                data = (
                    inn, name, type_id, rating, index, region, city,
                    street, house, last_name, first_name, middle_name,
                    phone, email
                )
                add_partner(self.parent.cursor, self.parent.db_connection, data)
        except Exception as e:
            print(f"Ошибка при сохранении партнера: {e}")
            QMessageBox.critical(None, "Ошибка", f"Не удалось сохранить данные партнера. Подробности: {e}", QMessageBox.Ok)