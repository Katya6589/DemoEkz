from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit, QComboBox, QSpinBox, QFormLayout, \
    QLabel, QMessageBox
from db import get_partner_data
from SavePartner import PartnerForm
from SalesHistory import SalesHistoryPage

class EditPartnerPage(PartnerForm):
    def __init__(self, parent):
        super().__init__(parent)
        self.inn = None
        button_layout = QHBoxLayout()
        save_button = QPushButton("Сохранить")
        save_button.setStyleSheet("background-color: #67BA80;")
        save_button.clicked.connect(self.save_partner)
        history_button = QPushButton("История реализации")
        history_button.setStyleSheet("background-color: #67BA80;")
        history_button.clicked.connect(self.show_sales_history)
        button_layout.addWidget(save_button)
        button_layout.addWidget(history_button)
        self.layout().addLayout(button_layout)

    def load_partner_data(self, inn):
        try:
            partner = get_partner_data(self.parent.cursor, inn)
            if partner:
                self.inn = partner[0]
                self.inn_input.setText(str(partner[0]))
                self.name_input.setText(partner[1])
                self.type_combo.setCurrentIndex(partner[2] - 1)
                self.rating_spin.setValue(partner[3])
                self.phone_input.setText(partner[4])
                self.email_input.setText(partner[5])
                self.index_input.setText(str(partner[6]))
                self.region_input.setText(partner[7])
                self.city_input.setText(partner[8])
                self.street_input.setText(partner[9])
                self.house_input.setText(partner[10])
                self.director_last_name_input.setText(partner[11])
                self.director_first_name_input.setText(partner[12])
                self.director_middle_name_input.setText(partner[13])
        except Exception as e:
            print(f"Ошибка при загрузке данных партнера: {e}")

    def show_sales_history(self):
        if not self.inn:
            QMessageBox.warning(None, "Предупреждение", "Выберите партнера для просмотра истории.", QMessageBox.Ok)
            return
        sales_history_page = SalesHistoryPage(self.parent, self.inn)
        self.parent.stacked_widget.addWidget(sales_history_page)
        self.parent.stacked_widget.setCurrentWidget(sales_history_page)