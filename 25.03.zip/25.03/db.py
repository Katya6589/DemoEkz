import sqlite3
from PyQt5.QtWidgets import QMessageBox

def connect_to_database():
    try:
        conn = sqlite3.connect("Master_pol.db")
        cursor = conn.cursor()
        return conn, cursor
    except sqlite3.Error as e:
        print(f"Ошибка подключения к базе данных: {e}")
        QMessageBox.critical(None, "Ошибка", f"Не удалось подключиться к базе данных. Подробности: {e}", QMessageBox.Ok)
        return None, None

def create_tables(cursor):
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Material_type (
        ID_Tip_materiala INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        Tip_materiala VARCHAR(255) NOT NULL,
        Procent_braka_materiala REAL NOT NULL
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Partner_products (
        INN_ID INTEGER NOT NULL,
        Artikul_ID INTEGER NOT NULL,
        Kolichestvo_produkcii INTEGER NOT NULL,
        Data_prodazhi DATE NOT NULL,
        FOREIGN KEY (INN_ID) REFERENCES Partners(ID_INN),
        FOREIGN KEY (Artikul_ID) REFERENCES Products(ID_Artikul)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Partners (
        ID_INN INTEGER NOT NULL PRIMARY KEY,
        Naimenovanie_partnera VARCHAR(255) NOT NULL,
        Tip_partnera_ID INTEGER NOT NULL,
        Rejting INTEGER NOT NULL,
        Indeks INTEGER NOT NULL,
        Oblast VARCHAR(255) NOT NULL,
        Gorod VARCHAR(255) NOT NULL,
        Ulica VARCHAR(255) NOT NULL,
        Dom VARCHAR(6) NOT NULL,
        Familiya VARCHAR(100) NOT NULL,
        Imya VARCHAR(100) NOT NULL,
        Otchestvo VARCHAR(100) NOT NULL,
        Telefon_partnera VARCHAR(16) NOT NULL,
        Elektronnaya_pochta_partnera VARCHAR(100) NOT NULL,
        FOREIGN KEY (Tip_partnera_ID) REFERENCES Partners_type(ID_Tip_partnera)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Partners_type (
        ID_Tip_partnera INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        Tip VARCHAR(255) NOT NULL
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Product_type (
        ID_Tip_produkcii INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        Type_produkcii VARCHAR(255) NOT NULL,
        Koefficient_tipa_produkcii REAL NOT NULL
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Products (
        ID_Artikul INTEGER NOT NULL PRIMARY KEY,
        Naimenovanie_produkcii VARCHAR(255) NOT NULL,
        Tip_produkcii_ID INTEGER NOT NULL,
        Minimalnaya_stoimost_dlya_partnera REAL NOT NULL,
        FOREIGN KEY (Tip_produkcii_ID) REFERENCES Product_type(ID_Tip_produkcii)
    );
    """)

def insert_test_data(cursor, conn):
    cursor.execute("INSERT OR IGNORE INTO Partners_type (Tip) VALUES ('ЗАО');")
    cursor.execute("INSERT OR IGNORE INTO Partners_type (Tip) VALUES ('ООО');")
    cursor.execute("INSERT OR IGNORE INTO Partners_type (Tip) VALUES ('ПАО');")
    cursor.execute("INSERT OR IGNORE INTO Partners_type (Tip) VALUES ('ОАО');")

    cursor.execute("""
    INSERT OR IGNORE INTO Partners (
        ID_INN, Naimenovanie_partnera, Tip_partnera_ID, Rejting, Indeks, Oblast, Gorod, Ulica, Dom, 
        Familiya, Imya, Otchestvo, Telefon_partnera, Elektronnaya_pochta_partnera
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """, (1237, "Партнер 1", 1, 10, 143960, "Московская", "Реутов", "Свободы", "51", "Иванов", "Иван", "Иванович", "+7 223 322 22 32", "ivanov@example.com"))

    cursor.execute("""
    INSERT OR IGNORE INTO Partners (
        ID_INN, Naimenovanie_partnera, Tip_partnera_ID, Rejting, Indeks, Oblast, Gorod, Ulica, Dom, 
        Familiya, Imya, Otchestvo, Telefon_partnera, Elektronnaya_pochta_partnera
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """, (12348, "Партнер 2", 2, 8, 652050, "Кемеровская", "Юрга", "Лесная", "15", "Петров", "Петр", "Петрович", "+7 493 123 45 67", "petrov@example.com"))

    cursor.execute("INSERT OR IGNORE INTO Partner_products (INN_ID, Artikul_ID, Kolichestvo_produkcii, Data_prodazhi) VALUES (?, ?, ?, ?);", (1, 101, 15000, "2023-01-01"))
    cursor.execute("INSERT OR IGNORE INTO Partner_products (INN_ID, Artikul_ID, Kolichestvo_produkcii, Data_prodazhi) VALUES (?, ?, ?, ?);", (2, 102, 12000, "2023-02-01"))

    conn.commit()

def get_partners(cursor):
    query = """
    SELECT 
        p.ID_INN, pt.Tip, p.Naimenovanie_partnera, 
        SUM(pp.Kolichestvo_produkcii) AS total_quantity,
        p.Telefon_partnera, p.Rejting,
        p.Familiya, p.Imya, p.Otchestvo
    FROM 
        Partners p
    JOIN 
        Partners_type pt ON p.Tip_partnera_ID = pt.ID_Tip_partnera
    LEFT JOIN 
        Partner_products pp ON p.ID_INN = pp.INN_ID
    GROUP BY 
        p.ID_INN, pt.Tip, p.Naimenovanie_partnera,
        p.Telefon_partnera, p.Rejting,
        p.Familiya, p.Imya, p.Otchestvo;
    """
    cursor.execute(query)
    return cursor.fetchall()

def get_partner_types(cursor):
    query = "SELECT ID_Tip_partnera, Tip FROM Partners_type;"
    cursor.execute(query)
    return cursor.fetchall()

def get_partner_data(cursor, inn):
    query = """
    SELECT 
        ID_INN, Naimenovanie_partnera, Tip_partnera_ID, Rejting, Telefon_partnera, 
        Elektronnaya_pochta_partnera, Indeks, Oblast, Gorod, Ulica, Dom, 
        Familiya, Imya, Otchestvo
    FROM 
        Partners
    WHERE ID_INN = ?;
    """
    cursor.execute(query, (inn,))
    return cursor.fetchone()

def add_partner(cursor, conn, data):
    query = """
    INSERT INTO Partners (
        ID_INN, Naimenovanie_partnera, Tip_partnera_ID, Rejting, Indeks, 
        Oblast, Gorod, Ulica, Dom, Familiya, Imya, Otchestvo, 
        Telefon_partnera, Elektronnaya_pochta_partnera
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """
    cursor.execute(query, data)
    conn.commit()

def update_partner(cursor, conn, data):
    query = """
    UPDATE Partners
    SET 
        Naimenovanie_partnera = ?, 
        Tip_partnera_ID = ?, 
        Rejting = ?, 
        Telefon_partnera = ?, 
        Elektronnaya_pochta_partnera = ?,
        Indeks = ?, 
        Oblast = ?, 
        Gorod = ?, 
        Ulica = ?, 
        Dom = ?,
        Familiya = ?, 
        Imya = ?, 
        Otchestvo = ?
    WHERE ID_INN = ?;
    """
    cursor.execute(query, data)
    conn.commit()

def get_sales_history(cursor, inn):
    query = """
    SELECT 
        p.Naimenovanie_produkcii, pp.Kolichestvo_produkcii, pp.Data_prodazhi
    FROM 
        Partner_products pp
    JOIN 
        Products p ON pp.Artikul_ID = p.ID_Artikul
    WHERE 
        pp.INN_ID = ?;
    """
    cursor.execute(query, (inn,))
    return cursor.fetchall()

def calculate_material_quantity(cursor, product_type_id, material_type_id, product_count, param1, param2):
    query = """
    SELECT 
        pt.Koefficient_tipa_produkcii, mt.Procent_braka_materiala
    FROM 
        Product_type pt
    JOIN 
        Material_type mt ON pt.ID_Tip_produkcii = ? AND mt.ID_Tip_materiala = ?;
    """
    try:
        cursor.execute(query, (product_type_id, material_type_id))
        result = cursor.fetchone()
        if not result:
            return -1
        coefficient, defect_rate = result
        required_material = product_count * param1 * param2 * coefficient
        required_material_with_defect = required_material / (1 - defect_rate)
        return int(required_material_with_defect)
    except sqlite3.Error as e:
        print(f"Ошибка при расчете материалов: {e}")
        return -1