from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (
    QDialog
)
from PyQt5.uic import loadUi

class WelcomeScreen(QDialog):
    def __init__(self):
        super(WelcomeScreen, self).__init__()
        loadUi("WelcomeScreen.ui", self)
        self.Password.setEchoMode(QtWidgets.QLineEdit.Password)
        self.Vxod.clicked.connect(self.signinfunc)

    def signinfunc(self):
        login = self.Login.text()
        passw = self.Password.text()
        if len(login) == 0 or len(passw) == 0:
            self.
