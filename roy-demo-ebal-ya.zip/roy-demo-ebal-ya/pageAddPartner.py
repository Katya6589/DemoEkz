from PyQt5.QtWidgets import QMessageBox


class PageAddPartner:
    def __init__(self, ui, db, main_window):
        self.ui = ui
        self.db = db
        self.main_window = main_window

        self.ui.btnSave.clicked.connect(self.submit_partner)
        self.ui.btnBack.clicked.connect(self.go_back)

        self.current_partner = None
        self.original_inn = None

    def fill_form_for_editing(self, partner):
        self.current_partner = partner
        (inn, tip, name, quantity, phone, rating, fam, imya, otch) = partner
        self.original_inn = inn
        self.ui.innInput.setText(str(inn))
        self.ui.nameInput.setText(name)
        match tip:
            case "ЗАО":
                tip = 0
            case "ООО":
                tip = 1
            case "ПАО":
                tip = 2
            case "ОАО":
                tip = 3
            case _:
                tip = 0
        self.ui.typeCombo.setCurrentIndex(tip)
        self.ui.ratingSpin.setValue(rating)
        self.ui.indexInput.setText(str(quantity))
        self.ui.phoneInput.setText(phone)
        self.ui.lastNameInput.setText(fam)
        self.ui.firstNameInput.setText(imya)
        self.ui.middleNameInput.setText(otch)

        self.ui.btnSave.setText("Обновить")

    def submit_partner(self):
        try:
            data = (
                int(self.ui.innInput.text()),
                self.ui.nameInput.text(),
                self.ui.typeCombo.currentIndex() + 1,
                int(self.ui.ratingSpin.value()),
                int(self.ui.indexInput.text()),
                self.ui.regionInput.text(),
                self.ui.cityInput.text(),
                self.ui.streetInput.text(),
                self.ui.houseInput.text(),
                self.ui.lastNameInput.text(),
                self.ui.firstNameInput.text(),
                self.ui.middleNameInput.text(),
                self.ui.phoneInput.text(),
                self.ui.emailInput.text()
            )

            if self.current_partner is None:
                print("ADD")
                self.db.add_partner(data)
                QMessageBox.information(self.ui.pageAddPartner, "Успех", "Партнёр успешно добавлен!")
            else:
                print("UPD")
                self.db.update_partner(data, self.original_inn)
                QMessageBox.information(self.ui.pageAddPartner, "Успех", "Партнёр успешно обновлён!")

            self.ui.stackedWidget.setCurrentWidget(self.ui.pagePartners)
            self.main_window.partnersPage.setupPage()

        except Exception as e:
            QMessageBox.critical(self.ui.pageAddPartner, "Ошибка", f"Не удалось сохранить партнёра:\n{e}")

    def go_back(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.pagePartners)
