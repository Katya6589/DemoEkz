import sqlite3

class Database:
    def __init__(self, db_name="Master_pol.db"):
        self.db_connection = None
        self.cursor = None
        self.db_name = db_name
        self.connect()

    def connect(self):
        try:
            self.db_connection = sqlite3.connect(self.db_name)
            self.cursor = self.db_connection.cursor()
            print("Подключение к базе данных успешно.")
            # Включаем проверку внешних ключей
            self.cursor.execute("PRAGMA foreign_keys = ON;")
        except sqlite3.Error as e:
            print(f"Ошибка подключения к базе данных: {e}")
            raise

    def initialize(self):
        try:
            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Material_type (
                ID_Tip_materiala INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                Tip_materiala VARCHAR(255) NOT NULL,
                Procent_braka_materiala REAL NOT NULL
            );
            """)

            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Partners_type (
                ID_Tip_partnera INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                Tip VARCHAR(255) NOT NULL
            );
            """)

            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Product_type (
                ID_Tip_produkcii INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                Type_produkcii VARCHAR(255) NOT NULL,
                Koefficient_tipa_produkcii REAL NOT NULL
            );
            """)

            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Partners (
                ID_INN INTEGER NOT NULL PRIMARY KEY,
                Naimenovanie_partnera VARCHAR(255) NOT NULL,
                Tip_partnera_ID INTEGER NOT NULL,
                Rejting INTEGER NOT NULL,
                Indeks INTEGER NOT NULL,
                Oblast VARCHAR(255) NOT NULL,
                Gorod VARCHAR(255) NOT NULL,
                Ulica VARCHAR(255) NOT NULL,
                Dom VARCHAR(6) NOT NULL,
                Familiya VARCHAR(100) NOT NULL,
                Imya VARCHAR(100) NOT NULL,
                Otchestvo VARCHAR(100) NOT NULL,
                Telefon_partnera VARCHAR(16) NOT NULL,
                Elektronnaya_pochta_partnera VARCHAR(100) NOT NULL,
                FOREIGN KEY (Tip_partnera_ID) REFERENCES Partners_type(ID_Tip_partnera)
            );
            """)

            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Products (
                ID_Artikul INTEGER NOT NULL PRIMARY KEY,
                Naimenovanie_produkcii VARCHAR(255) NOT NULL,
                Tip_produkcii_ID INTEGER NOT NULL,
                Minimalnaya_stoimost_dlya_partnera REAL NOT NULL,
                FOREIGN KEY (Tip_produkcii_ID) REFERENCES Product_type(ID_Tip_produkcii)
            );
            """)

            self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Partner_products (
                INN_ID INTEGER NOT NULL,
                Artikul_ID INTEGER NOT NULL,
                Kolichestvo_produkcii INTEGER NOT NULL,
                Data_prodazhi DATE NOT NULL,
                FOREIGN KEY (INN_ID) REFERENCES Partners(ID_INN) ON UPDATE CASCADE,
                FOREIGN KEY (Artikul_ID) REFERENCES Products(ID_Artikul)
            );
            """)

            self.cursor.execute("INSERT OR IGNORE INTO Partners_type (ID_Tip_partnera, Tip) VALUES (1, 'ЗАО');")
            self.cursor.execute("INSERT OR IGNORE INTO Partners_type (ID_Tip_partnera, Tip) VALUES (2, 'ООО');")
            self.cursor.execute("INSERT OR IGNORE INTO Partners_type (ID_Tip_partnera, Tip) VALUES (3, 'ПАО');")
            self.cursor.execute("INSERT OR IGNORE INTO Partners_type (ID_Tip_partnera, Tip) VALUES (4, 'ОАО');")

            self.cursor.execute("INSERT OR IGNORE INTO Product_type (ID_Tip_produkcii, Type_produkcii, Koefficient_tipa_produkcii) VALUES (?, ?, ?);",
                               (1, "Тип 1", 1.5))
            self.cursor.execute("INSERT OR IGNORE INTO Product_type (ID_Tip_produkcii, Type_produkcii, Koefficient_tipa_produkcii) VALUES (?, ?, ?);",
                               (2, "Тип 2", 1.8))

            self.cursor.execute("INSERT OR IGNORE INTO Products (ID_Artikul, Naimenovanie_produkcii, Tip_produkcii_ID, Minimalnaya_stoimost_dlya_partnera) VALUES (?, ?, ?, ?);",
                               (101, "Продукт 1", 1, 100.0))
            self.cursor.execute("INSERT OR IGNORE INTO Products (ID_Artikul, Naimenovanie_produkcii, Tip_produkcii_ID, Minimalnaya_stoimost_dlya_partnera) VALUES (?, ?, ?, ?);",
                               (102, "Продукт 2", 2, 150.0))

            self.cursor.execute("""
            INSERT OR IGNORE INTO Partners (
                ID_INN, Naimenovanie_partnera, Tip_partnera_ID, Rejting, Indeks, Oblast, Gorod, Ulica, Dom, 
                Familiya, Imya, Otchestvo, Telefon_partnera, Elektronnaya_pochta_partnera
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (1237, "Партнер 1", 1, 10, 143960, "Московская", "Реутов", "Свободы", "51",
                  "Иванов", "Иван", "Иванович", "+7 223 322 22 32", "ivanov@example.com"))

            self.cursor.execute("""
            INSERT OR IGNORE INTO Partners (
                ID_INN, Naimenovanie_partnera, Tip_partnera_ID, Rejting, Indeks, Oblast, Gorod, Ulica, Dom, 
                Familiya, Imya, Otchestvo, Telefon_partnera, Elektronnaya_pochta_partnera
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (12348, "Партнер 2", 2, 8, 652050, "Кемеровская", "Юрга", "Лесная", "15",
                  "Петров", "Петр", "Петрович", "+7 493 123 45 67", "petrov@example.com"))

            self.cursor.execute("INSERT OR IGNORE INTO Partner_products (INN_ID, Artikul_ID, Kolichestvo_produkcii, Data_prodazhi) VALUES (?, ?, ?, ?);",
                               (1237, 101, 15000, "2023-01-01"))
            self.cursor.execute("INSERT OR IGNORE INTO Partner_products (INN_ID, Artikul_ID, Kolichestvo_produkcii, Data_prodazhi) VALUES (?, ?, ?, ?);",
                               (12348, 102, 12000, "2023-02-01"))

            self.db_connection.commit()
            print("База данных инициализирована успешно.")
        except sqlite3.Error as e:
            print(f"Ошибка при инициализации базы данных: {e}")
            raise

    def get_partners(self):
        query = """
        SELECT 
            p.ID_INN, 
            pt.Tip, 
            p.Naimenovanie_partnera, 
            COALESCE(SUM(pp.Kolichestvo_produkcii), 0) AS total_quantity,
            p.Telefon_partnera, 
            p.Rejting,
            p.Familiya, 
            p.Imya, 
            p.Otchestvo
        FROM 
            Partners p
        JOIN 
            Partners_type pt ON p.Tip_partnera_ID = pt.ID_Tip_partnera
        LEFT JOIN 
            Partner_products pp ON p.ID_INN = pp.INN_ID
        GROUP BY 
            p.ID_INN, 
            pt.Tip, 
            p.Naimenovanie_partnera,
            p.Telefon_partnera, 
            p.Rejting,
            p.Familiya, 
            p.Imya, 
            p.Otchestvo;
        """
        try:
            self.cursor.execute(query)
            return self.cursor.fetchall()
        except sqlite3.Error as e:
            print(f"Ошибка при загрузке партнеров: {e}")
            raise

    def add_partner(self, partner_data):
        query = """
        INSERT INTO Partners (
            ID_INN, Naimenovanie_partnera, Tip_partnera_ID, Rejting, Indeks, Oblast, Gorod,
            Ulica, Dom, Familiya, Imya, Otchestvo, Telefon_partnera, Elektronnaya_pochta_partnera
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """
        try:
            self.cursor.execute(query, partner_data)
            self.db_connection.commit()
            print("Партнёр успешно добавлен.")
        except sqlite3.IntegrityError:
            print("Ошибка: партнёр с таким ИНН уже существует.")
        except sqlite3.Error as e:
            print(f"Ошибка при добавлении партнёра: {e}")
            raise

    def update_partner(self, partner_data, original_inn):
        query = """
        UPDATE Partners SET
            ID_INN = ?, 
            Naimenovanie_partnera = ?, 
            Tip_partnera_ID = ?, 
            Rejting = ?, 
            Indeks = ?, 
            Oblast = ?, 
            Gorod = ?, 
            Ulica = ?, 
            Dom = ?, 
            Familiya = ?, 
            Imya = ?, 
            Otchestvo = ?, 
            Telefon_partnera = ?, 
            Elektronnaya_pochta_partnera = ?
        WHERE ID_INN = ?;
        """
        try:
            params = partner_data + (original_inn,)
            print("Параметры запроса:", params)

            self.cursor.execute("SELECT COUNT(*) FROM Partners WHERE ID_INN = ?", (original_inn,))
            count = self.cursor.fetchone()[0]
            if count == 0:
                print(f"Ошибка: ID_INN {original_inn} не найден в таблице Partners")
                raise ValueError(f"ID_INN {original_inn} не существует")

            new_inn = partner_data[0]
            if new_inn != original_inn:
                self.cursor.execute("SELECT COUNT(*) FROM Partners WHERE ID_INN = ?", (new_inn,))
                if self.cursor.fetchone()[0] > 0:
                    print(f"Ошибка: Новый ID_INN {new_inn} уже существует")
                    raise ValueError(f"ID_INN {new_inn} уже существует")

            self.cursor.execute(query, params)
            print(f"Затронуто строк: {self.cursor.rowcount}")
            self.db_connection.commit()
            print("Партнёр успешно обновлён.")
        except sqlite3.Error as e:
            print(f"Ошибка при обновлении партнёра: {e}")
            raise


    def close(self):
        if self.db_connection:
            self.db_connection.close()
            print("Соединение с базой данных закрыто.")