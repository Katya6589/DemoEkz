import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from ui.dialog import Ui_MainWindow
from database import Database
from pagePartners import PartnersPage
from pageAddPartner import PageAddPartner

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.db = Database()
        #self.db.initialize()

        self.partnersPage = PartnersPage(self.ui, self.db, self.onPartnerClick)
        self.addPartnerPage = PageAddPartner(self.ui, self.db, self)

        self.ui.btnAddPartner.clicked.connect(self.showAddPartnerPage)
        self.ui.btnBack.clicked.connect(self.showPartnersPage)

        self.partnersPage.setupPage()

    def onPartnerClick(self, partner):
        print(partner)
        self.addPartnerPage.fill_form_for_editing(partner)
        self.ui.stackedWidget.setCurrentWidget(self.ui.pageAddPartner)

    def showAddPartnerPage(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.pageAddPartner)

    def showPartnersPage(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.pagePartners)
        self.partnersPage.setupPage()



app = QApplication(sys.argv)
window = MainWindow()
window.show()
sys.exit(app.exec_())
