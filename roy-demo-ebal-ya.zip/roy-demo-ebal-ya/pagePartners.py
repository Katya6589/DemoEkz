from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QFrame, QVBoxLayout, QLabel
from PyQt5.QtCore import Qt


def calculate_discount(quantity):
    if quantity < 10000:
        return 0
    elif 10000 <= quantity < 50000:
        return 5
    elif 50000 <= quantity < 300000:
        return 10
    else:
        return 15


def createPartnerBlock(partner, on_click):
    (inn, tip, name, quantity, phone, rating, fam, imya, otch) = partner

    block = QFrame()
    block.setFrameShape(QFrame.StyledPanel)
    block.setStyleSheet("background-color: #9c8989; border-radius: 10px; padding: 10px;")
    block.setMinimumHeight(120)  # Увеличим минимальную высоту для размещения скидки
    block.setLayout(QVBoxLayout())

    layout = block.layout()

    labelName = QLabel(f"<b>{name}</b> ({tip})")
    labelInfo = QLabel(f"""
ИНН: {inn}
Телефон: {phone}
Рейтинг: {rating}
""")
    labelPerson = QLabel(f"Контакт: {fam} {imya} {otch}")

    for lbl in (labelName, labelInfo, labelPerson):
        lbl.setStyleSheet("color: white;")
        layout.addWidget(lbl)

    # --- Добавим скидку ---
    discount_value = calculate_discount(quantity)
    discount_label = QLabel(f"Скидка: {discount_value}%")
    discount_label.setParent(block)
    discount_label.setStyleSheet("""
        color: yellow;
        font-size: 18px;
        font-weight: bold;
        background-color: rgba(0,0,0,0.3);
        padding: 4px 8px;
        border-radius: 6px;
    """)
    discount_label.adjustSize()  # Вычислить размер текста
    discount_label.move(block.width() - discount_label.width() - 10, 10)
    discount_label.raise_()

    # Переместим скидку при изменении размера блока
    def resizeEvent(event):
        discount_label.move(block.width() - discount_label.width() - 10, 10)

    block.resizeEvent = resizeEvent

    block.mousePressEvent = lambda event, p=partner: on_click(p)

    return block



class PartnersPage:
    def __init__(self, ui, db, on_partner_click):
        self.ui = ui
        self.db = db
        self.on_partner_click = on_partner_click
        self.setupPage()

    def setupPage(self):
        if self.ui.scrollAreaWidgetContents_2.layout() is None:
            self.ui.scrollAreaWidgetContents_2.setLayout(QtWidgets.QVBoxLayout())

        layout = self.ui.scrollAreaWidgetContents_2.layout()

        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        self.loadPartners()

    def loadPartners(self):
        partners = self.db.get_partners()

        layout = self.ui.scrollAreaWidgetContents_2.layout()
        for partner in partners:
            block = createPartnerBlock(partner, self.on_partner_click)
            layout.addWidget(block)